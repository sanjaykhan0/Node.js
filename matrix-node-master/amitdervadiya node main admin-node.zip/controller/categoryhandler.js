const adminSchema = require('../model/adminSchema')
const fs = require('fs')


module.exports.addcategory = (req,res)=>{
    res.render('addcategory')
}